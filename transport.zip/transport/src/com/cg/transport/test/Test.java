package com.cg.transport.test;

import org.junit.BeforeClass;

import com.cg.transportservice.bean.TicketBean;
import com.cg.transportservice.exception.TicketException;
import com.cg.transportservice.service.ITicketService;
import com.cg.transportservice.service.TicketServiceImpl;

class Test {

	private static ITicketService service;
	boolean result;
	double balance;

	@BeforeClass
	public static void createInstance() {
		service = new TicketServiceImpl();
	}
	@org.junit.Test
	public void testCreateAccount() throws TicketException {
	
	TicketBean bean = new TicketBean();
	service.addTransportTicket(bean);
	
	}
	

}
