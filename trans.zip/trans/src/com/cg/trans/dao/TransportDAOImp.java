package com.cg.trans.dao;

import java.util.HashMap;
import java.util.Set;

import com.cg.trans.bean.Bean;
import com.cg.trans.util.DataBase;

public class TransportDAOImp implements ITransportDAO {
	DataBase dataBase=new DataBase();
	HashMap<Integer,Bean> map=dataBase.Booking();
	

	@Override
	public HashMap<String, String> getTransportDetails() {
		// TODO Auto-generated method stub
		return dataBase.getTransportDetails();
	}

	@Override
	public Bean addBooking(Bean bean) {
		// TODO Auto-generated method stub
		return dataBase.addBooking(bean);
	}

	@Override
	public HashMap<Integer, Bean> display(Bean bean) {
		// TODO Auto-generated method stub
		return dataBase.display(bean);
	}

	@Override
	public boolean update(int id1) {
		boolean b2=false;
		Set<Integer> element=map.keySet();
		for (Integer integer : element) {
			System.out.println("hii");
			if(map.containsKey(id1)) {
				map.get(id1).setReason("dfcmdsnbfjm");;
				System.out.println(map.get(id1));
				b2=true;
			}
			
		}	
		
		
		return b2;
	}

	@Override
	public boolean remove(int id2) {
		boolean b4=false;
		Set<Integer> element=map.keySet();
		for (Integer integer : element) {
			if(map.containsKey(id2)) {
				map.remove(id2);
				b4=true;
			}
			
		}	
		
		return b4;
	}

	

	

}
