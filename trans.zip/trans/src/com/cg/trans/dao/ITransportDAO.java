package com.cg.trans.dao;

import java.util.HashMap;

import com.cg.trans.bean.Bean;

public interface ITransportDAO {

	HashMap<String, String> getTransportDetails();

	Bean addBooking(Bean bean);

	HashMap<Integer, Bean> display(Bean bean);

	

	

	

	boolean remove(int id2);

	boolean update(int id1);

}
