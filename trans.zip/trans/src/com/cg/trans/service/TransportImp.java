package com.cg.trans.service;

import java.util.HashMap;

import com.cg.trans.bean.Bean;
import com.cg.trans.dao.ITransportDAO;
import com.cg.trans.dao.TransportDAOImp;

public class TransportImp implements ITransport {

	ITransportDAO dao=new TransportDAOImp();
	@Override
	public HashMap<String, String> getTransportDetails() {
		// TODO Auto-generated method stub
		return dao.getTransportDetails();
	}

	@Override
	public Bean addBooking(Bean bean) {
		// TODO Auto-generated method stub
		return dao.addBooking(bean);
	}

	@Override
	public HashMap<Integer, Bean> display(Bean bean) {
		// TODO Auto-generated method stub
		return dao.display(bean);
	}

	@Override
	public boolean update(int id1) {
		// TODO Auto-generated method stub
		return dao.update(id1);
	}

	@Override
	public boolean remove(int id2) {
		// TODO Auto-generated method stub
		return dao.remove(id2);
	}

}
