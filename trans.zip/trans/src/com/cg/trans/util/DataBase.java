package com.cg.trans.util;

import java.util.HashMap;

import com.cg.trans.bean.Bean;

public class DataBase {

	
	private  HashMap<String, String> transportDetails=new HashMap<>();
	private  HashMap<Integer, Bean> transport=new HashMap<>();
	
	
	public  HashMap<String, String> getTransportDetails(){
		
		
		transportDetails.put("f-1", "flight");
		transportDetails.put("ta-1", "taxi");
		transportDetails.put("t-1", "train");
		
		
		
		
		
		
		return transportDetails;
		
		
	}

		public  Bean addBooking(Bean bean) {
					return transport.put(bean.getId(), bean);
	}

		
		public  HashMap<Integer, Bean> display(Bean bean) {
			// TODO Auto-generated method stub
			return transport;
		}

		public  HashMap<Integer, Bean> Booking() {
			// TODO Auto-generated method stub
			return transport;
		}
	
	
	
	
	
}
