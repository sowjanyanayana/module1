package com.cg.trans.client;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

import com.cg.trans.bean.Bean;
import com.cg.trans.service.ITransport;
import com.cg.trans.service.TransportImp;
import com.cg.trans.util.DataBase;

public class Client {

	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		ITransport service = new TransportImp();
		HashMap<String, String> transportDetails = service.getTransportDetails();
		while (true) {
			Bean bean = new Bean();
			System.out.println("1.add\n2.display 3.update\n4.remove\n5.exit");
			System.out.println("choice");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				int id = (int) ((Math.random()) * 10000);
				bean.setId(id);
				// set TransportCategoryId
				int count = 0;
				Set<String> key = transportDetails.keySet();
				for (String string : key) {

					count++;
					System.out.println(count + "." + transportDetails.get(string));

				}

				System.out.println(" enter transport option :");
				int option = scanner.nextInt();
				int count1 = 1;

				Set<String> key1 = transportDetails.keySet();
				for (String string : key1) {

					if (count1 == option) {
						bean.setTransId(transportDetails.get(string));
					}
					count1++;
				}

				// set reason
				System.out.println(" enter reason");
				scanner.nextLine();
				String reason = scanner.nextLine();
				// or String reason = scanner.next();

				bean.setReason(reason);
				// set when
				System.out.println(" enter when");
				System.out.println(" 1. this week \n 2. nect week \n 3. next month");
				int whenChoice = scanner.nextInt();
				if (whenChoice == 1) {
					bean.setWhen("this week");
				} else if (whenChoice == 2) {
					bean.setWhen("next week");
				} else if (whenChoice == 3) {
					bean.setWhen("next month");
				}
				
				LocalDateTime dateTime = LocalDateTime.now();
				DateTimeFormatter format = DateTimeFormatter.ofPattern("dd MMMM yyyy hh:mm a");
				service.addBooking(bean);
				System.out.println(" bopoked with id " + bean.getId() + " on " + dateTime.format(format));
				
				break;
			case 2:
				HashMap<Integer, Bean> b2=service.display(bean);
				Set<Integer> key2 = b2.keySet();
				for (Integer string : key2) {
						System.out.println(b2);
				}
				
				break;
			case 3:
				System.out.println("enter id");
				int id1=scanner.nextInt();
				 boolean b1=service.update(id1);
				 if(b1) {
					 System.out.println("updated");
				 }
				break;
			case 4:
				System.out.println("enter id");
				int id2=scanner.nextInt();
				boolean b3=service.remove(id2);
				if(b3) {
					System.out.println("removed");
				}
				break;
			case 5:
				System.exit(0);
			}

		}

	}

}
