package com.cg.trans.bean;

public class Bean {

	
	
	private int id;
	private String when;
	private String reason;
	private String transId;
	private String status="new";
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getWhen() {
		return when;
	}
	public void setWhen(String when) {
		this.when = when;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "[id=" + id + ", when=" + when + ", reason=" + reason + ", transId=" + transId + ", status="
				+ status+"]" ;
	}
	
	
	
	
}
